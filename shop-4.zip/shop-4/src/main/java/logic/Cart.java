package logic;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

public class Cart {
	//itemList: ������ ��ϵ� ��ٱ��� ��ǰ
	private List<ItemSet> itemList = new ArrayList<ItemSet>();
	public List<ItemSet> getItemList() {
		return itemList;
	}
	
	//itemSet : �߰��� ��ǰ
	public void push(ItemSet itemSet) {
		for(ItemSet is : itemList) {
			if(is.getItem().getId() == itemSet.getItem().getId()) {
				is.setQuantity(is.getQuantity() + itemSet.getQuantity());
				return;
			}
		}
		itemList.add(itemSet);
	}

	public boolean isEmpty() {
		return itemList==null || itemList.size() == 0;
	}
	
	//��ٱ����� ��ǰ ������ ������ ����
	public int getTotalAmount() {
		int tot = 0;
		for(int i = 0 ; i < itemList.size() ; i++) {
			int itemPrice = itemList.get(i).getItem().getPrice();
			int quantity = itemList.get(i).getQuantity();
			tot += (itemPrice * quantity);
		}
		 return tot;
	}
	/*
	 tot = 0;
	 for(ItemSet is : itemList) {
	 tot += is.getItem().getPrice() * is.getQuantity();
	 }
	 return tot;
	 
	 tot = 0;
		 Iterator<ItemSet> it = itemList.iterator();
		 while(it.hasNext()) {
		 ItemSet is = it.next();
		 tot += is.getItem().getPrice() * is.getQuantity();
		 }
	 return tot;
	 */

	public void clearAll(HttpSession session) {
		itemList = new ArrayList<ItemSet>();
		session.setAttribute("CART", this);
	}
}
