package dao;

import org.springframework.stereotype.Repository;

@Repository
public class BuildingDaoImpl implements BuildingDao {

}
