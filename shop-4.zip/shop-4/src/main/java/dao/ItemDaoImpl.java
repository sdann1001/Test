package dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import dao.mapper.ItemMapper;
import logic.Item;

@Repository
public class ItemDaoImpl implements ItemDao{
	/*private NamedParameterJdbcTemplate template;
	private RowMapper<Item> mapper =
			new BeanPropertyRowMapper<Item>(Item.class);
	@Autowired
	public void setDataSource(DataSource dataSource) {
		template = new NamedParameterJdbcTemplate(dataSource);
	}*/
	
	//sqlSession: org.mybatis.spring.SqlSessionTemplate ��ü����.
	//������, Ŀ�ؼ� �� ����������.
	@Autowired
	private SqlSessionTemplate sqlSession;
	private final String NS = "dao.mapper.ItemMapper.";
	
	@Override
	public List<Item> list() { //item���̺��� ��� ������ �Ѱ���.
		//selectList: ListŸ������ ��ȸ�� ��� ���ڵ带 ��ü�� �����ؼ� ����.
		//"select * from item order by id";
		return sqlSession.selectList(NS+"list");
	}
	/*@Override
	public void insert(Item item) {
		int i = template.queryForObject("select ifnull(max(id),0) from item", 
				new HashMap<String, Object>(), Integer.class);
		item.setId(++i);
		String sql = "insert into item (id, name, price, description, pictureUrl)"
				+ " values(:id, :name, :price, :description, :pictureUrl)";
		SqlParameterSource param =
				new BeanPropertySqlParameterSource(item);
		template.update(sql, param);
	}*/
	public void insert(Item item) {
		int i = sqlSession.getMapper(ItemMapper.class).maxid();
		item.setId(++i);
		sqlSession.getMapper(ItemMapper.class).insert(item);
	}
	@Override
	public Item itemDetail(String id) {
		Map<String, String> map = new HashMap<String,String>();
		map.put("id", id);
		//String sql = "select * from item where id=:id";
		//selectOne: ��ȸ�� ���ڵ尡 �Ѱ��� ��츸 ����. ������ null��.
		return sqlSession.selectOne(NS+"list", map);
	}
	/*
	@Override
	public void update(Item item) {
		String sql ="update item set name=:name, price=:price, "
				+" description=:description, pictureUrl=:pictureUrl where id=:id";
		SqlParameterSource param = new BeanPropertySqlParameterSource(item);
		template.update(sql, param);
	}*/
	
	@Override
	public void update(Item item) {
		sqlSession.getMapper(ItemMapper.class).update(item);
	}
	
	/*
	@Override
	public void itemDelete(String id) {
		Map<String, String> map = new HashMap<String,String>();
		map.put("id", id);
		String sql = "delete from item where id=:id";
		template.update(sql, map);
	}*/
	
	@Override
	public void itemDelete(String id) {
		sqlSession.getMapper(ItemMapper.class).delete(id);
	}
}
