package dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import dao.mapper.SaleItemMapper;
import dao.mapper.SaleMapper;
import logic.Sale;
import logic.SaleItem;

@Repository
public class SaleItemDaoImpl implements SaleItemDao{
	/*private NamedParameterJdbcTemplate template;
	private RowMapper<SaleItem> mapper = new BeanPropertyRowMapper<SaleItem>(SaleItem.class);
	@Autowired
	public void setDataSource(DataSource dataSource) {
		template = new NamedParameterJdbcTemplate(dataSource);
	}*/
	@Autowired
	private SqlSessionTemplate sqlSession;
	private final String NS = "dao.mapper.SaleItemMapper.";

	/*@Override
	public void insert(SaleItem saleItem) {
		String sql = "insert into saleitem"
				+ " (saleid, saleitemid, itemid, quantity, updatetime)"
				+ " values(:saleId, :saleItemId, :item.id, :quantity, :updateTime)";
		SqlParameterSource param =
				new BeanPropertySqlParameterSource(saleItem);
		template.update(sql, param);
	}*/
	@Override
	public void insert(SaleItem saleItem) {
		sqlSession.getMapper(SaleItemMapper.class).insert(saleItem);
	}

	/*@Override
	public List<SaleItem> list(Integer saleId) {
		String sql = "select * from saleitem where saleid=:saleId";
		Map<String, Integer> param = new HashMap<String, Integer>();
		param.put("saleId", saleId);
		return template.query(sql, param, mapper);
	}*/
	@Override
	public List<SaleItem> list(Integer saleId) {
		Map<String, Integer> param = new HashMap<String, Integer>();
		param.put("saleId", saleId);
		return sqlSession.selectList(NS+"list", param);
	}
}
