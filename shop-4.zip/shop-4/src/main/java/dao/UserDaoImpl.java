package dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import dao.mapper.BoardMapper;
import dao.mapper.ItemMapper;
import dao.mapper.UserMapper;
import logic.User;

@Repository//@Component + DB���� ��ü ���
public class UserDaoImpl implements UserDao{
	/*private NamedParameterJdbcTemplate template;
	private RowMapper<User> mapper =
			new BeanPropertyRowMapper<User>(User.class);
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		template = new NamedParameterJdbcTemplate(dataSource);
	}*/
	@Autowired
	private SqlSessionTemplate sqlSession;
	private final String NS = "dao.mapper.UserMapper.";
	
	/*
	@Override
	public void insert(User user) {
		String sql = "insert into userAccount "
				+"(userid, username, password, birthday, phoneno, postcode, address, email) "
				+"values (:userId, :userName, :password, :birthDay, :phoneNo, :postcode, :address, :email)";
		SqlParameterSource param = new BeanPropertySqlParameterSource(user);
		template.update(sql, param);
	}*/
	@Override
	public void insert(User user) {
		sqlSession.getMapper(UserMapper.class).insert(user);
	}

	/*@Override
	public User select(String userId) {
		String sql = "select * from userAccount where userid=:userId";
		Map<String, String> param = new HashMap<String, String>();
		param.put("userId", userId);
		return template.queryForObject(sql, param, mapper);
	}*/
	@Override
	public User select(String userId) {
		Map<String, String> map = new HashMap<String,String>();
		map.put("userId", userId);
		return sqlSession.selectOne(NS+"list", map);
	}

	/*@Override
	public void update(User user) {
		String sql = "update userAccount set username=:userName,"
				+ " birthday=:birthDay, phoneNo=:phoneNo, postcode=:postcode, address=:address, email=:email"
				+ " where userid=:userId";
		SqlParameterSource param = new BeanPropertySqlParameterSource(user);
		template.update(sql, param);
	}*/
	@Override
	public void update(User user) {
		sqlSession.getMapper(UserMapper.class).update(user);
	}

	/*@Override
	public List<User> list() {
		String sql = "select * from userAccount";
		return template.query(sql, mapper);
	}*/
	@Override
	public List<User> list() {
		return sqlSession.selectList(NS+"list");
	}

	/*@Override
	public void delete(String id) {
		String sql = "delete from userAccount where userid=:userId";
		Map<String, String> param = new HashMap<String, String>();
		param.put("userId", id);
		template.update(sql, param);
	}*/
	@Override
	public void delete(String id) {
		sqlSession.getMapper(UserMapper.class).delete(id);
	}

	/*@Override
	public List<User> list(String[] ids) {
		String idlist = "";
		for(int i = 0 ; i < ids.length ; i++) {
			idlist += "'" + ids[i] + ((i==ids.length-1)?"'":"',");
		}
		String sql = "select * from useraccount where userid in (" + idlist + ") and not userid='admin'";
		return template.query(sql,mapper);
	}*/
	@Override
	public List<User> list(String[] ids) {
		//List��ü : �����迭. �迭���·� ����.
		List<String> idlist = Arrays.asList(ids);
		Map<String, List<String>> param = new HashMap<String, List<String>>();
		param.put("idlist", idlist);
		return sqlSession.selectList(NS+"list",param);
	}

	@Override
	public List<Map<String, Object>> mygraph(String userId) {
		/*Map<String, String> map = new HashMap<String,String>();
		map.put("userId", userId);*/
		return sqlSession.getMapper(UserMapper.class).mygraph(userId);
	}
}
