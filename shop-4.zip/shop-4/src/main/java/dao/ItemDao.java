package dao;

import java.util.List;

import logic.Item;

public interface ItemDao {
	List<Item> list();

	void insert(Item item);

	Item itemDetail(String id);

	void update(Item item);

	void itemDelete(String id);
}
