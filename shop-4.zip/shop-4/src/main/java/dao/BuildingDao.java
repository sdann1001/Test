package dao;

public interface BuildingDao {

}
