package dao;

import java.util.List;
import java.util.Map;

import logic.User;

public interface UserDao {

	void insert(User user);

	User select(String userId);

	void update(User user);

	List<User> list();

	void delete(String id);

	List<User> list(String[] ids);

	List<Map<String,Object>> mygraph(String userId);

}
