package dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import dao.mapper.SaleMapper;
import dao.mapper.UserMapper;
import logic.Sale;

@Repository
public class SaleDaoImpl implements SaleDao{
	
	@Autowired
	private SqlSessionTemplate sqlSession;
	private final String NS = "dao.mapper.SaleMapper.";
	
	/*
	@Override
	public Integer getMaxSaleId() {
		//sale���̺��� ����� saleid�� �� �ִ밪�� ����
		String sql = "select ifnull(max(saleid), 0) from sale";
		Integer ret = template.queryForObject(sql, new HashMap(), Integer.class);
		return ret + 1;
	}
	 */
	@Override
	public Integer getMaxSaleId() {
		//sale���̺��� ����� saleid�� �� �ִ밪�� ����
		int ret = sqlSession.getMapper(SaleMapper.class).maxid();
		return ret + 1;
	}
	/*
	@Override
	public void insert(Sale sale) {
		String sql= "insert into sale (saleid, userid, updatetime)"
				+" values (:saleId, :user.userId, :updateTime)";
		SqlParameterSource param =
				new BeanPropertySqlParameterSource(sale);
		template.update(sql, param);
	}
	*/
	@Override
	public void insert(Sale sale) {
		sqlSession.getMapper(SaleMapper.class).insert(sale);
	}

	/*@Override
	public List<Sale> list(String id) {
		String sql = "select * from sale where userid=:userId";
		Map<String, String> param = new HashMap<String, String>();
		param.put("userId", id);
		return template.query(sql, param, mapper);
	}*/
	@Override
	public List<Sale> list(String id) {
		Map<String, String> param = new HashMap<String, String>();
		param.put("userid", id);
		return sqlSession.selectList(NS+"list", param);
	}
}
