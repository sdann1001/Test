package dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import dao.mapper.BoardMapper;
import dao.mapper.UserMapper;
import logic.Board;

@Repository
public class BoardDaoImpl implements BoardDao{
	/*private NamedParameterJdbcTemplate template;
	private RowMapper<Board> mapper =
			new BeanPropertyRowMapper<Board>(Board.class);
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		template = new NamedParameterJdbcTemplate(dataSource);
	}*/
	@Autowired
	private SqlSessionTemplate sqlSession;
	private final String NS = "dao.mapper.BoardMapper.";

	/*@Override
	public int count(String searchType, String searchContent) {
		String sql = "select count(*) from board";
		if(searchType != null && searchContent != null) {
			sql += " where " + searchType + " like " + " '%" + searchContent + "%'";
		}
		Integer ret = template.queryForObject(sql, new HashMap<>(), Integer.class);
		return ret;
	}*/
	@Override
	public int count(String searchType, String searchContent) {
		Map<String, String> param = new HashMap<String, String>();
		param.put("serchType", searchType);
		param.put("searchContent", searchContent);
		Integer ret = sqlSession.selectOne(NS+"count", param);
		return ret;
	}

	@Override
	public List<Board> list(String searchType, String searchContent, Integer pageNum, int limit) {
		Map<String, Object> param = new HashMap<String, Object>();
		int startrow = (pageNum - 1) * limit;
		param.put("startrow", startrow);
		param.put("limit", limit);
		param.put("searchType", searchType);
		param.put("searchContent", searchContent);
		return sqlSession.selectList(NS+"list", param);
	}

	/*@Override
	public Board getBoard(Integer num) {
		String sql = "select num, name, pass, subject, content, readcnt, file1 fileurl," + 
				     "regdate, ref, reflevel, refstep from board where num = :num";
		Map <String, Integer> param = new HashMap<String, Integer>();
		param.put("num", num);
		return template.queryForObject(sql, param, mapper);
	}*/
	@Override
	public Board getBoard(Integer num) {
		Map <String, Integer> param = new HashMap<String, Integer>();
		param.put("num", num);
		param.put("startrow", 0);
		param.put("limit", 1);
		return sqlSession.selectOne(NS+"list", param);
	}

	/*@Override
	public void write(Board board) {
		String sql = "insert into board (num, name, pass, subject, content, readcnt, file1,"
				+ "regdate, ref, reflevel, refstep)"
				+ " values(:num, :name, :pass, :subject, :content, 0, "
				+ ":fileurl, now(), :ref, :reflevel, :refstep)";
		SqlParameterSource param =
				new BeanPropertySqlParameterSource(board);
		template.update(sql, param);
	}*/
	@Override
	public void write(Board board) {
		sqlSession.getMapper(BoardMapper.class).write(board);
	}
	
	/*@Override
	public int maxNum() {
		int i = template.queryForObject("select ifnull(max(num),0) from board", 
				new HashMap<>(), Integer.class);
		return i;
	}*/
	public int maxNum() {
		Integer i = sqlSession.selectOne(NS+"maxNum");
		return i;
	}

	/*@Override
	public void readcntupdate(Integer num) {
		String sql = "update board set readcnt = readcnt + 1 where num=:num";
		Map <String, Integer> param = new HashMap<String, Integer>();
		param.put("num", num);
		template.update(sql, param);
	}*/
	@Override
	public void readcntupdate(Integer num) {
		Map <String, Integer> param = new HashMap<String, Integer>();
		param.put("num", num);
		sqlSession.getMapper(BoardMapper.class).readcntupdate(num);
	}

	/*
	@Override
	public void refstepadd(Board board) {
		String sql = "update board set refstep = refstep + 1"
				   + " where ref = :ref and refstep > :refstep";
	    SqlParameterSource param =
					new BeanPropertySqlParameterSource(board);
	    template.update(sql, param);
	}*/
	@Override
	public void refstepadd(Board board) {
		sqlSession.getMapper(BoardMapper.class).refstepadd(board);
	}

	/*@Override
	public void update(Board board) {
		String sql = "update board set name = :name, subject = :subject,"
				+ " content = :content, file1 = :fileurl where num = :num";
		SqlParameterSource param =
				new BeanPropertySqlParameterSource(board);
		template.update(sql, param);
	}*/
	public void update(Board board) {
		sqlSession.getMapper(BoardMapper.class).boardUpdate(board);
	}

	/*@Override
	public void delete(Integer num) {
		String sql = "delete from board where num = :num";
		Map <String, Integer> param = new HashMap<String, Integer>();
		param.put("num", num);
		template.update(sql, param);
	}*/
	@Override
	public void delete(Integer num) {
		sqlSession.getMapper(BoardMapper.class).boardDelete(num);
	}

	@Override
	public List<Map<String, Object>> graph() {
		return sqlSession.getMapper(BoardMapper.class).graph();
	}

}
