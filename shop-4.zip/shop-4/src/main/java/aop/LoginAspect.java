package aop;

import javax.servlet.http.HttpSession;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import exception.LoginException;
import logic.User;

@Component //��üȭ
@Aspect //aopŬ������ ���
public class LoginAspect {
	//UserController.mypage�޼ҵ尡 ȣ��Ǳ� ���� userLoginCheck(..) �޼ҵ尡 ȣ���.
	@Around("execution(* controller.User*.my*(..))")
	public Object userLoginCheck(ProceedingJoinPoint joinPoint) throws Throwable {
		String id = null;
		HttpSession session = null;
		User paramUser = null;
		if(joinPoint.getArgs()[0] instanceof User) {
			paramUser = (User)joinPoint.getArgs()[0];
			session = (HttpSession)joinPoint.getArgs()[2];
			id = paramUser.getUserId();
		} else {
		id = (String)joinPoint.getArgs()[0]; //�Ķ����id��
		session = (HttpSession)joinPoint.getArgs()[1];
		}
		User loginUser = (User)session.getAttribute("loginUser");
		if(loginUser == null) {
			throw new LoginException("�α��� �� �ŷ��ϼ���", "../user/login.shop");
		}
		if(!id.equals(loginUser.getUserId()) && !loginUser.getUserId().equals("admin")) {
			throw new LoginException("���θ� �ŷ� �����մϴ�." , "../user/myPage.shop?id="+loginUser.getUserId());
		}
		Object ret = joinPoint.proceed();
		return ret;
	}
	
	@Around("execution(* controller.Admin*.*(..))")
	public Object adminLoginCheck(ProceedingJoinPoint joinPoint) throws Throwable {
		HttpSession session = null;
		User loginUser = null;
		boolean adminable = false;
		for(int i=0; i < joinPoint.getArgs().length; i++) {
			if(joinPoint.getArgs()[i] instanceof HttpSession) {
				session = (HttpSession)joinPoint.getArgs()[i];
				loginUser = (User)session.getAttribute("loginUser");
				if(loginUser == null) {
					throw new LoginException("�����ڷ� �α��� �ϼ���", "../user/login.shop");
				}
				if(!loginUser.getUserId().equals("admin")) {
					throw new LoginException
					("�����ڸ� ������ �����Դϴ�.", "../user/myPage.shop?id=" + loginUser.getUserId());
				}
				adminable = true;
				break;
			}
		}
		if(!adminable) {
			throw new LoginException("����η� ��ȭ�ϼ���. ���� ��ü�� �䱸��",
					"../user/myPage.shop?id=" + loginUser.getUserId());
		}
		Object ret = joinPoint.proceed();
		return ret;
	}
}
