package aop;

import javax.servlet.http.HttpSession;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import exception.CartEmptyException;
import exception.LoginException;
import logic.Cart;
import logic.User;

@Component
@Aspect
public class CartAspect {
	@Around("execution(* controller.Cart*.check*(..))")
	public Object cartCheck(ProceedingJoinPoint joinPoint) throws Throwable {
		HttpSession session = null;
		session = (HttpSession)joinPoint.getArgs()[0];
		User loginUser = (User)session.getAttribute("loginUser");
		Cart cart = (Cart)session.getAttribute("CART");
		if(loginUser == null) {
			throw new LoginException("�α��� �� �ŷ��ϼ���", "../user/login.shop");
		}
		if(cart == null) {
			throw new CartEmptyException("��ٱ��ϰ� ������ϴ�" , "../item/list.shop");
		}
		Object ret = joinPoint.proceed();
		return ret;
	}
}
