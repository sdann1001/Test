package controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import exception.LoginException;
import exception.ShopException;
import logic.Item;
import logic.Sale;
import logic.SaleItem;
import logic.ShopService;
import logic.User;

@Controller
public class UserController {
	@Autowired
	ShopService service;

	@ModelAttribute
	public User getUser() {
		return new User();
	}
	
	@RequestMapping("user/userForm")
	public ModelAndView userForm() {
		ModelAndView mav = new ModelAndView();
		mav.addObject(new User());
		return mav;
	}

	@RequestMapping(value = "user/login", method = RequestMethod.GET)
	public String loginForm() {
		return "user/login";
	}

	/*ModelAndView mav = new ModelAndView("user/login");
	if (bindingResult.hasErrors()) {
		mav.getModel().putAll(bindingResult.getModel());
		return mav;
	}
	try {
		User dbUser = service.getUser(user.getUserId());
		if (dbUser.getPassword().equals(user.getPassword())) {
			mav.addObject("dbUser", dbUser);
			mav.setViewName("user/loginSuccess");
			session.setAttribute("loginUser", dbUser);
		} else {
			bindingResult.reject("error.login.password");
			mav.getModel().putAll(bindingResult.getModel());
			return mav;
		}
	} catch (EmptyResultDataAccessException e) {
		bindingResult.reject("error.login.id");
		mav.getModel().putAll(bindingResult.getModel());
	}
	return mav;*/
	@RequestMapping(value = "user/login", method = RequestMethod.POST)
	public ModelAndView login(@Valid User user, BindingResult bindingResult, HttpSession session) {
		ModelAndView mav = new ModelAndView("user/login");
		if (bindingResult.hasErrors()) {
			mav.getModel().putAll(bindingResult.getModel());
			return mav;
		}
		User dbUser = service.getUser(user.getUserId());
		if (dbUser == null) {
			bindingResult.reject("error.login.id");
			mav.getModel().putAll(bindingResult.getModel());
			return mav;
		}
		if (dbUser.getPassword().equals(user.getPassword())) {
			mav.addObject("dbUser", dbUser);
			mav.setViewName("user/loginSuccess");
			session.setAttribute("loginUser", dbUser);
		} else {
			bindingResult.reject("error.login.password");
			mav.getModel().putAll(bindingResult.getModel());
			return mav;
		}
		return mav;
	}

	@RequestMapping("user/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:login.shop";
	}

	@RequestMapping("user/userEntry")
	public ModelAndView userEntry(@Valid User user, BindingResult bindingResult) {
		ModelAndView mav = new ModelAndView("user/userForm");
		if (bindingResult.hasErrors()) {
			mav.getModel().putAll(bindingResult.getModel());
			return mav;
		}
		try {
			// user: ȭ�鿡�� �Էµ� ������ �����ϰ� �ִ� ��ü
			service.userCreate(user);
			mav.setViewName("user/login");
			mav.addObject("user", user);
			// DataIntegrityViolationException : �⺻Ű�� �ߺ��� ��� �߻��Ǵ� ����
		} catch (DataIntegrityViolationException e) {
			bindingResult.reject("error.duplicate.user");
		}
		return mav;
	}

	@RequestMapping("user/myPage")
	public ModelAndView mypage(String id, HttpSession session) {
		ModelAndView mav = new ModelAndView();
		User user = service.getUser(id);
		List<Sale> salelist = service.saleList(id);
		for (Sale sale : salelist) {
			List<SaleItem> saleItemList = service.saleItemList(sale.getSaleId());
			int amount = 0;
			for (SaleItem sitem : saleItemList) {
				Item item = service.itemDetail(sitem.getItemId() + "");
				sitem.setItem(item);
				amount += sitem.getQuantity() * item.getPrice();
			}
			sale.setSaleItemList(saleItemList);
			sale.setAmount(amount);
		}
		mav.addObject("salelist", salelist);
		mav.addObject("user", user);
		return mav;
	}

	@RequestMapping(value = "user/update", method = RequestMethod.GET)
	public ModelAndView myupdateForm(String id, HttpSession session) {
		ModelAndView mav = new ModelAndView();
		User user = service.getUser(id);
		mav.addObject("user", user);
		return mav;
	}

	@RequestMapping(value = "user/update", method = RequestMethod.POST)
	public ModelAndView myupdate(@Valid User user, BindingResult bindingResult, HttpSession session) {
		ModelAndView mav = new ModelAndView("user/update");
		if (bindingResult.hasErrors()) {
			mav.getModel().putAll(bindingResult.getModel());
			return mav;
		}
		User loginUser = (User) session.getAttribute("loginUser");
		User dbUser = service.getUser(user.getUserId());
		if (loginUser.getUserId().equals("admin")) {
			if (!user.getPassword().equals(loginUser.getPassword())) {
				throw new ShopException("�����ڰ� ��й�ȣ�� Ʋ���ϴ�.", "update.shop?id=" + user.getUserId());
			}
		} else {
			if (!user.getPassword().equals(dbUser.getPassword())) {
				throw new ShopException("��й�ȣ�� Ʋ���ϴ�.", "update.shop?id=" + user.getUserId());
			}
		}
		try {
			service.updateUser(user);
			mav.setViewName("redirect:myPage.shop?id=" + user.getUserId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mav;
	}

	@RequestMapping(value = "user/delete", method = RequestMethod.GET)
	public ModelAndView mydeleteForm(String id, HttpSession session) {
		ModelAndView mav = new ModelAndView();
		User user = service.getUser(id);
		mav.addObject("user", user);
		return mav;
	}

	@RequestMapping(value = "user/delete", method = RequestMethod.POST)
	public String mydelete(String id, HttpSession session, String password) {
		User loginUser = (User)session.getAttribute("loginUser");
		User user = service.getUser(id);
		if (user == null) {
			throw new ShopException("���� ��� ����ڰ� �������� �ʽ��ϴ�.", "myPage.shop?id=" + id);
		}
		if (loginUser.getUserId().equals("admin")) {
			if (!loginUser.getPassword().equals(password)) {
				throw new LoginException("������ ��й�ȣ�� Ʋ���ϴ�.", "delete.shop?id=" + id);
			}
		} else { // �Ϲݻ������ ���
			if (!user.getPassword().equals(password)) {
				throw new LoginException("��й�ȣ�� Ʋ���ϴ�.", "delete.shop?id=" + id);
			}
		}
		try {
			service.userDelete(id);
			if (loginUser.getUserId().equals("admin")) {// �����ڷα���
				return "redirect:../admin/admin.shop";
			} else {// �Ϲݻ���ڷ� �α��ν� ���� ����
				session.invalidate(); // �α׾ƿ�
				return "redirect:login.shop";
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new ShopException("������ ���� �߻�", "../user/myPage.shop?id=" + id);
		}
	}
	
	@RequestMapping("user/mygraph*")
	public ModelAndView mygraph(String id, HttpSession session) {
		ModelAndView mav = new ModelAndView();
		Map<String, Object> map = service.mygraph(id);
		Map treemap = new TreeMap<String, Object>(map);
		mav.addObject("map", treemap);
		return mav;
	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}
}
