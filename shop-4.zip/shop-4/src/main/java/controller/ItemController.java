package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import logic.Item;
import logic.ShopService;

@Controller //@Component�� ������ü. @Component + Controller ��� �ο�
public class ItemController {
	@Autowired
	private ShopService service;
	
	@RequestMapping("item/list") //��û ������ ���� ȣ��Ǵ� �޼ҵ� ����
	public ModelAndView list() {
		//itemList: item���̺��� ��� ������ Item��ü�� List�� ����.
		List<Item> itemList = service.getItemList();
		ModelAndView mav = new ModelAndView();
		mav.addObject("itemList", itemList);
		return mav;
	}
	
	@RequestMapping("item/create")
	public ModelAndView create() {
		ModelAndView mav = new ModelAndView("item/add");
		mav.addObject(new Item());
		return mav;
	}
	
	@RequestMapping("item/register")
	public ModelAndView register(@Valid Item item, BindingResult bindingResult, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView("item/add");
		if(bindingResult.hasErrors()) {
			mav.getModel().putAll(bindingResult.getModel());
			return mav;
		}
		service.itemCreate(item, request);
		mav.setViewName("redirect:/item/list.shop");
		return mav;
	}
	
	/* ��ǰ �����ϱ� /item/update.shop?id=1, ���Ͼ��ε�, ��ȿ������
	 */
	@RequestMapping("item/update")
	public ModelAndView update(@Valid Item item, BindingResult bindingResult, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView("item/edit");
		if(bindingResult.hasErrors()) {
			mav.getModel().putAll(bindingResult.getModel());
			return mav;
		}
		service.itemUpdate(item, request);
		mav.setViewName("redirect:/item/list.shop");
		return mav;
	}
	
	@RequestMapping("item/delete")
	public String delete(String id) {
		ModelAndView mav = new ModelAndView();
		try {
			service.itemDelete(id);
			return "redirect:list.shop";
		} catch (Exception e) {
			return "redirect:confirm.shop?id=" + id;
		}
	}
	
	/*/..../item/detail.shop?id=1
	 * ��ǰ�󼼺���: id�Ķ���Ͱ� ���۵�.
	 * 1. id�Ķ���͸� �̿��ؼ� DB��ȸ�ϱ�
	 * 2. ��ȸ�� DB�� ������ view�� �����ϱ�
	 */
	@RequestMapping("item/*")
	public ModelAndView detail(String id) {
		ModelAndView mav = new ModelAndView();//"item/detail"��� ��.
		Item item = service.itemDetail(id);
		mav.addObject("item", item);
		return mav;
	}
	
/*	@RequestMapping("item/edit")
	public ModelAndView edit(String id) {
		return detail(id);
	}*/
}
