package controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import exception.ShopException;
import logic.Board;
import logic.ShopService;

@Controller
public class BoardController {
	
	@Autowired
	private ShopService service;
	
	@RequestMapping("board/list")
	public ModelAndView list(Integer pageNum, String searchType, String searchContent) {
		if(pageNum == null || pageNum.toString().equals("")) {
			pageNum=1;
		}
		ModelAndView mav = new ModelAndView();
		int limit = 10;
		int listcount = service.boardcount(searchType, searchContent);
		List<Board> boardlist = service.boardList(searchType, searchContent, pageNum, limit);
		int maxpage = (int)((double)listcount/limit + 0.95);
		int startpage = ((int)((pageNum/10.0 + 0.9) -1)) * 10 + 1;
		int endpage = startpage + 9;
		if(endpage > maxpage) endpage = maxpage;
		int boardcnt = listcount - (pageNum - 1) * limit;
		mav.addObject("pageNum", pageNum);
		mav.addObject("maxpage", maxpage);
		mav.addObject("startpage", startpage);
		mav.addObject("endpage", endpage);
		mav.addObject("listcount",listcount);
		mav.addObject("boardlist", boardlist);
		mav.addObject("boardcnt", boardcnt);
		return mav;
	}
	
	//�Խñ� ����ϱ�: 
	//1. ��ȿ�� ����
	//2. DB�� ����ϱ�
	//3. ��� ���� => list.shop
	//   ��� ���� => write.shop
	@RequestMapping(value="board/write", method=RequestMethod.POST)
	public ModelAndView write(@Valid Board board, BindingResult bindingResult,
			HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		if (bindingResult.hasErrors()) {
			mav.getModel().putAll(bindingResult.getModel());
			return mav;
		}
		try {
			service.write(board, request);
			mav.setViewName("redirect:list.shop");
		}catch (Exception e) {
			e.printStackTrace();
			throw new ShopException("�Խù� ��� ����", "write.shop");
		}
		return mav;
	}
	
	@RequestMapping(value="board/reply", method=RequestMethod.POST)
	public ModelAndView reply(@Valid Board board,
			BindingResult bindingResult) {
		ModelAndView mav = new ModelAndView();
		if(bindingResult.hasErrors()) {
			mav.getModel().putAll(bindingResult.getModel());
			board = service.getBoard(board.getNum());
			mav.addObject("board",board);
			return mav;
		}
		try {
			service.boardReply(board);
			mav.setViewName("redirect:list.shop");
		} catch(Exception e) {
			e.printStackTrace();
			throw new ShopException("�Խù� ��� ����", "reply.shop");
		}
		return mav;
	}
	
	@RequestMapping(value="board/update", method=RequestMethod.POST)
	public ModelAndView update(@Valid Board board, BindingResult bindingResult,
			HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		Board dbboard = service.getBoard(board.getNum());
		if (bindingResult.hasErrors()) {
			mav.getModel().putAll(bindingResult.getModel());
			mav.addObject("board", dbboard);
			return mav;
		}
		if(!board.getPass().equals(dbboard.getPass())) {
			throw new ShopException("��й�ȣ�� Ʋ���ϴ�.", 
					"update.shop?num=" + board.getNum() + "&pageNum="
					+ request.getParameter("pageNum"));
		}
		if(board.getFile1() == null || board.getFile1().isEmpty()) {
			board.setFileurl(request.getParameter("file2"));
		}
		try {
			service.update(board, request);
			mav.setViewName("/board/detail");
		}catch (Exception e) {
			e.printStackTrace();
			throw new ShopException("�Խù� ���� ����", "update.shop?num=" + board.getNum() + "&pageNum="
					+ request.getParameter("pageNum"));
		}
		return mav;
	}
	//@RequestMapping(value="board/delete", method=RequestMethod.POST)
	public ModelAndView delete(Integer num, String pass, Integer pageNum) {
		ModelAndView mav = new ModelAndView();
		Board dbboard = service.getBoard(num);
		if(!pass.equals(dbboard.getPass())) {
			throw new ShopException("��й�ȣ�� Ʋ���ϴ�.", 
					"delete.shop?num=" + num + "&pageNum="
					+ pageNum);
		}
		try {
			service.delete(num);
			mav.setViewName("redirect:list.shop?pageNum=" + pageNum);
		} catch(Exception e) {
			e.printStackTrace();
			throw new ShopException("�Խù� ���� ����", "delete.shop?num=" + num
			+"&pageNum="+ pageNum);
		}
		return mav;
	}
	
	@RequestMapping(value="board/*", method=RequestMethod.GET)
	public ModelAndView detail(Integer num, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		Board board = new Board();
		if(num != null) {
			board = service.getBoard(num);
			String url = request.getServletPath();
			if(url.contains("/board/detail.shop")) {
				service.updatereadcnt(num);
			}
		}
		mav.addObject("board",board);
	    return mav;
	}
	@RequestMapping(value="board/delete", method=RequestMethod.POST)
	public ModelAndView delete2(@RequestParam HashMap<String, String> map) {
		int num = Integer.parseInt(map.get("num"));
		int pageNum = Integer.parseInt(map.get("pageNum"));
		String pass = map.get("pass");
		Board dbboard = service.getBoard(num);
		System.out.println(map);
		ModelAndView mav = new ModelAndView();
		if(!pass.equals(dbboard.getPass())) {
			throw new ShopException("��й�ȣ�� Ʋ���ϴ�.", 
					"delete.shop?num=" + num + "&pageNum="
					+ pageNum );
		}
		try {
			service.delete(num);
			mav.setViewName("redirect:list.shop?pageNum=" + pageNum);
		} catch(Exception e) {
			e.printStackTrace();
			throw new ShopException("�Խù� ���� ����", "delete.shop?num=" + num
			+"&pageNum="+ pageNum);
		}
		return mav;
	}
}
